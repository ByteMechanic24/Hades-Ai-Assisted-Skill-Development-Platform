"""
Durable Orchestration State & Roadmap Chunk Persistence (Step 4)

Persists and retrieves OrchestrationState and RoadmapChunk objects using
PostgreSQL memory_chunks (with structured metadata) and provides safe in-memory fallback.
"""

import json
import logging
from typing import Optional, List, Dict, Any

from app.schemas.models import OrchestrationState, RoadmapChunk
from app.db.connection import db_manager, DatabaseManager
from app.db.memory import save_memory, get_similar_memories, get_learner_memories
from app.db.exceptions import DatabaseError, LearnerNotFoundError

logger = logging.getLogger(__name__)

# In-memory fast cache for active sessions / offline tests
_STATE_CACHE: Dict[str, OrchestrationState] = {}
_CHUNK_CACHE: Dict[str, List[RoadmapChunk]] = {}


def save_orchestration_state(
    state: OrchestrationState,
    manager: Optional[DatabaseManager] = None,
) -> None:
    """
    Persists an OrchestrationState snapshot to the in-memory cache and PostgreSQL memory_chunks.
    """
    # 1. Update in-memory session cache
    _STATE_CACHE[state.session_id] = state.model_copy(deep=True)

    # 2. Persist snapshot into PostgreSQL memory_chunks as an episodic checkpoint
    try:
        payload_meta = {
            "category": "orchestration_state",
            "session_id": state.session_id,
            "status": state.status,
            "active_topic": state.active_topic,
            "target_goal": state.target_goal,
            "current_topic_index": state.current_topic_index,
            "available_topics_count": len(state.available_topics),
            "generated_chunks_count": len(state.generated_chunks),
            "prefetched_topics": state.prefetched_topics,
        }
        
        # We store summary content for fast semantic retrieval
        summary_content = (
            f"Orchestration State for learner {state.learner_id} (Session {state.session_id}): "
            f"Status={state.status}, ActiveTopic={state.active_topic or 'None'}, "
            f"Goal={state.target_goal or 'None'}. "
            f"AvailableTopics={', '.join(state.available_topics[:5])}"
        )
        
        save_memory(
            external_id=state.learner_id,
            content=summary_content,
            metadata=payload_meta,
            manager=manager or db_manager,
        )
        logger.debug("Persisted OrchestrationState for session %s in DB", state.session_id)
    except Exception as exc:
        logger.warning(
            "Non-blocking DB persistence failure for session %s: %s", state.session_id, exc
        )


def get_orchestration_state(
    session_id: str,
    learner_id: Optional[str] = None,
    manager: Optional[DatabaseManager] = None,
) -> Optional[OrchestrationState]:
    """
    Retrieves the current OrchestrationState by session_id, checking in-memory cache first.
    """
    if session_id in _STATE_CACHE:
        return _STATE_CACHE[session_id].model_copy(deep=True)
    return None


def save_roadmap_chunk(
    learner_id: str,
    chunk: RoadmapChunk,
    manager: Optional[DatabaseManager] = None,
) -> None:
    """
    Persists an incremental RoadmapChunk for a learner.
    """
    if learner_id not in _CHUNK_CACHE:
        _CHUNK_CACHE[learner_id] = []
    
    # Avoid duplicate chunks in cache
    existing_ids = {c.chunk_id for c in _CHUNK_CACHE[learner_id]}
    if chunk.chunk_id not in existing_ids:
        _CHUNK_CACHE[learner_id].append(chunk)

    try:
        meta = {
            "category": "roadmap_chunk",
            "chunk_id": chunk.chunk_id,
            "roadmap_id": chunk.roadmap_id,
            "sequence_number": chunk.sequence_number,
            "title": chunk.title,
            "topics": chunk.topics,
            "has_more": chunk.has_more,
        }
        content = (
            f"Roadmap Chunk #{chunk.sequence_number} '{chunk.title}' for learner {learner_id}: "
            f"Topics: {', '.join(chunk.topics)}"
        )
        save_memory(
            external_id=learner_id,
            content=content,
            metadata=meta,
            manager=manager or db_manager,
        )
        logger.debug("Persisted RoadmapChunk %s for learner %s in DB", chunk.chunk_id, learner_id)
    except Exception as exc:
        logger.warning("Non-blocking DB chunk persistence failure: %s", exc)


def get_saved_roadmap_chunks(
    learner_id: str,
) -> List[RoadmapChunk]:
    """
    Retrieves all cached/saved roadmap chunks for a learner.
    """
    return list(_CHUNK_CACHE.get(learner_id, []))


def clear_state_cache() -> None:
    """Clears in-memory caches (for tests)."""
    _STATE_CACHE.clear()
    _CHUNK_CACHE.clear()
